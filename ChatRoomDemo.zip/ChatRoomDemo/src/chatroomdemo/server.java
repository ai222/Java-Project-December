package chatroomdemo;

import java.io.*;
import java.util.*;
import java.net.*;

public class server {

    static Vector<ClientHandler> ar = new Vector<>();
    static ArrayList names = new ArrayList();

    static int i = 0;

    public static void main(String[] args) throws IOException {
        ServerSocket ss = new ServerSocket(1235);
        Socket s;
        while (true) {
            s = ss.accept();
            System.out.println("New client request received : " + s);
            DataInputStream dis = new DataInputStream(s.getInputStream());
            DataOutputStream dos = new DataOutputStream(s.getOutputStream());
            System.out.println("Creating a new handler for this client...");
            ClientHandler mtch = new ClientHandler(s, "client " + i, dis, dos);
            Thread t = new Thread(mtch);
            System.out.println("Adding this client to active client list");
            ar.add(mtch);
            t.start();
            i++;
        }
    }
}

class ClientHandler implements Runnable {

    Scanner scn = new Scanner(System.in);
    private String name;
    final DataInputStream dis;
    final DataOutputStream dos;
    Socket s;
    boolean isloggedin;

    public ClientHandler(Socket s, String name,
            DataInputStream dis, DataOutputStream dos) {
        this.dis = dis;
        this.dos = dos;
        this.name = name;
        this.s = s;
        this.isloggedin = true;
    }

    @Override
    public void run() {

        String received;
        while (true) {
            try {
                // receive the string 
                received = dis.readUTF();
                String[] msgUser = null;

                System.out.println(received);

                if (received.contains("getUser")) {

                    msgUser = received.split(" ");
                    if (msgUser[0].equals("getUser")) {
                        received = "userList:";

                        server.names.add(msgUser[1].trim());
                        this.name = msgUser[1].trim();
                        System.err.println("names==" + server.names);
//                        for (int i = 0; i < server.names.size(); i++) {
//
//                            received = received + ":" + server.names.get(i);
//
//                        }
                        for (ClientHandler mc : server.ar) {

                            received = received + ":" + mc.name;

                        }
                    }
                } else if (received.contains("logout")) {
                    //server.names.remove(msgUser[1].trim());
                    this.isloggedin = false;
                    this.s.close();
                    break;
                }

                for (ClientHandler mc : server.ar) {

                    mc.dos.writeUTF(received);

                }

            } catch (IOException e) {

                server.ar.remove(this);

                Thread.currentThread().stop();
            }

        }
        try {
           
            this.dis.close();
            this.dos.close();

        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
